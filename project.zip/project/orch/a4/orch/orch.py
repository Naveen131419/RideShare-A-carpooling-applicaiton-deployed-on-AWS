import requests, json
from flask import Flask, jsonify
from flask import request
import datetime
import time

import docker
import pika
import uuid

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)

class read_req(db.Model):
	read_request_count=db.Column(db.Integer, primary_key=True,autoincrement = True)

def increment_count():
	row = read_req(content="new row") 
	db.session.add(row) 	
	db.session.commit()
def reset_count():
	query= "DELETE from read_req" 
	result = connection.execute(query)
def getCount(): 	
	query= "SELECT COUNT(*) from read_req" 	
	result = connection.execute(query) 	
	res = [dict(x) for x in result] 	
	count = res[0]["COUNT(*)"] 	
	return count

class read_helper():

	def __init__(self):
		pass

	def on_response(self, ch, method, props, body):
		if self.corr_id == props.correlation_id:
			self.response = body
		ch.basic_ack(delivery_tag=method.delivery_tag)

	def call(self, req):
		self.connection = pika.BlockingConnection(
			pika.ConnectionParameters(host='172.17.0.1'))

		self.channel = self.connection.channel()

		self.channel.queue_declare(queue='readQ')
		
		result = self.channel.queue_declare(queue='responseQ')
		self.callback_queue = result.method.queue

		self.channel.basic_consume(				#to wait for status code
			queue=self.callback_queue,
			on_message_callback=self.on_response,
			auto_ack=False)
		
		self.response = None
		self.corr_id = str(uuid.uuid4())
		self.channel.basic_publish(      #to send message
			exchange='',
			routing_key='readQ',
			properties=pika.BasicProperties(
				reply_to=self.callback_queue,
				correlation_id=self.corr_id,
				delivery_mode=2, # make message persistent
			),
			body=json.dumps(req))
		while self.response is None:
			self.connection.process_data_events()
		self.connection.close()
		return self.response


class write_helper():
	def __init__(self):
		pass

	def on_response(self, ch, method, props, body):
		if self.corr_id == props.correlation_id:
			self.response = body
		ch.basic_ack(delivery_tag=method.delivery_tag)
	def call(self,req):
		self.connection = pika.BlockingConnection( pika.ConnectionParameters(host='172.17.0.1'))
		self.channel = self.connection.channel()
		self.channel.queue_declare(queue='writeQ')
		self.corr_id = str(uuid.uuid4())
		self.channel.basic_publish(
			exchange='',
			routing_key='writeQ',
			properties=pika.BasicProperties(
				correlation_id=self.corr_id,
				# delivery_mode=2,  # make message persistent
			),
			body=json.dumps(req))
		self.connection.close()



app = Flask(__name__)
# client = docker.from_env()
client = docker.DockerClient(base_url='unix://var/run/docker.sock')
read_request_count = 0
no_of_slaves = 0




@app.route('/api/v1/db/read', methods=['POST'])
def read_db():
	#global read_request_count
	#read_request_count += 1
	increment_count()
	print("read_request_recieved")
	resp = read_rpc.call(request.get_json())
	print("/////////",resp)
	r = json.loads(resp)
	if type(r[0])!=str:
		return jsonify(r[0]),r[1]
	else:
		return jsonify(json.loads(r[0])),r[1]

@app.route('/api/v1/db/write', methods=['POST'])
def write_db():
	print("write_db invoked from orch")
	wr.call(request.get_json())
	return {}, 200

@app.route('/')
def hello_world():
	return 'Hello, World! From Orch'

def check_and_set(num):
	if no_of_slaves < num :
		create_slaves(num - no_of_slaves)
	else:
		remove_slaves(no_of_slaves - num)

def scale():
	read_request_count=getCount()
	sleepSec = 120
	time.sleep(sleepSec)
	while(True):
		pids = requests.get(url='http://0.0.0.0/api/v1/worker/list')
		print(pids, "Pids")
		pidList = json.loads(pids.text)
		if (read_request_count > 40) :
			check_and_set(3)
		elif (read_request_count > 20) :
			check_and_set(2)
		else:
			check_and_set(1)
		reset_count()
		#read_request_count = 0
		time.sleep(sleepSec)

@app.route("/api/v1/worker/list", methods=["GET"])
def worker_list():
	global client
	containers = [i.id for i in client.containers.list() if( i.name == "master" or "slave" in i.name)]
	print(containers)
	pids = [docker.APIClient().inspect_container(i)['State']['Pid'] for i in containers].sort()
	print(pids, "sorted list")
	return jsonify(pids),200

def create_slaves(n):
	global no_of_slaves
	while(n > 0):
		no_of_slaves += 1
		client.container.get(f"slave{no_of_slaves}").restart()
		n -= 1

def remove_slaves(n):
	global no_of_slaves
	while(n > 0):
		client.container.get(f"slave{no_of_slaves}").stop()
		no_of_slaves -= 1
		n -= 1

@app.route('/api/v1/crash/slave', methods=['POST'])
def crash_slave():
	global no_of_slaves
	if(no_of_slaves == 0):
		print("no containers to kill")
		return [],204
	pid = docker.APIClient().inspect_container(
		client.container.get(f"slave{no_of_slaves}"))['State']['Pid']
	remove_slaves(1)
	create_slaves(1)
	crashSlaveApiCalled = True
	return [f"{pid}"],200

'''@app.route('/api/v1/crash/master', methods=['POST'])
def crash_master():
	return {},200
	for i in client.containers.list():
		if(i.name == "master"):
			i.stop()
			i.remove()
	# convert_slave()'''

def start_workers():
	global client
	global no_of_slaves
	no_of_slaves = 1
	client.containers.get('master').restart();
	client.containers.get('slave1').restart();

def touch_workers():
	try:
		client.containers.get('master')
	except:
		client.containers.run(image='worker:latest',environment=["MASTER=YES"],entrypoint="python3 worker.py",name="master")
		client.containers.get('master').stop;
	try:
		client.containers.get('slave1')
	except:
		client.containers.run(image='worker:latest',environment=["MASTER=NO"],entrypoint="python3 worker.py",name=f"slave1")
		client.containers.get('slave1').stop;
	try:
		client.containers.get('slave2')
	except:
		client.containers.run(image='worker:latest', environment=["MASTER=NO"], entrypoint="python3 worker.py", name=f"slave2")
		client.containers.get('slave2').stop;
	try:
		client.containers.get('slave3')
	except:
		client.containers.run(image='worker:latest', environment=["MASTER=NO"], entrypoint="python3 worker.py", name=f"slave3")
		client.containers.get('slave3').stop;


if __name__ == "__main__":
	touch_workers()
	start_workers()
	read_rpc = read_helper()
	wr = write_helper()
	app.run(debug=True, host="0.0.0.0", port=8082)




