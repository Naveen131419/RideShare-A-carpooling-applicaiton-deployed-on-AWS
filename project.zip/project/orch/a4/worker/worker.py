import requests
import json
from flask import Flask, jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
import datetime, os

amIMaster = os.getenv('MASTER')

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///database.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


class User(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	username = db.Column(db.String(80), unique=True, nullable=False)
	password = db.Column(db.String(40), nullable=False)


class Rides(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	created_by = db.Column(db.String(80), nullable=False)
	timestamp = db.Column(db.String(80), nullable=False)
	source = db.Column(db.Integer, nullable=False)
	destination = db.Column(db.Integer, nullable=False)


class ID_UNAME(db.Model):
	id = db.Column(db.Integer, primary_key=True)
	rideid = db.Column(db.Integer, nullable=False)
	username = db.Column(db.String(80), nullable=False)


def read_db(request):
	print("read_db api invoked in worker")
	id = request["id"]
	if(id == 1):
		uname = request["username"]
		if(User.query.filter_by(username=uname).first()):
			return jsonify({"value": "exist"}),200
		else:
			return jsonify({"value": "no"}),200

	if(id == 2):
		uname = request["username"]
		if(User.query.filter_by(username=uname).first()):
			return jsonify({"value": "exist"}),200
		else:
			return jsonify({"value": "no"}),200

	if(id == 3):
		src = request["source"]
		dst = request["destination"]
		ride_list = Rides.query.filter_by(source=src, destination=dst).all()
		f_l = []
		for ride in ride_list:
			t1 = datetime.datetime.strptime(str(ride.timestamp), "%d-%m-%Y:%S-%M-%H")
			now = datetime.datetime.now().strftime("%d-%m-%Y:%S-%M-%H")
			now = datetime.datetime.strptime(str(now), "%d-%m-%Y:%S-%M-%H")
			if t1 > now:
				d = {}
				d["rideID"] = ride.id
				d["created_by"] = ride.created_by
				d["timestamp"] = ride.timestamp
				f_l.append(d)
		return jsonify({"ridesList": f_l}),200

	if(id == 4):
		rideid = request["rideid"]
		ride = Rides.query.filter_by(id=rideid).first()
		if(ride):
			d = {}
			d["rideID"] = ride.id
			d["created_by"] = ride.created_by
			l = ID_UNAME.query.filter_by(rideid=rideid).all()
			user = []
			for i in l:
				user.append(i.username)
			d["users"] = user
			d["timestamp"] = ride.timestamp
			d["source"] = ride.source
			d["destination"] = ride.destination
			return {"data": d}, 200

		else:
			return {}, 400
	if(id == 5):
		uname = request["username"]
		rideid = request["rideid"]
		if(User.query.filter_by(username=uname).first()):
			if(Rides.query.filter_by(id=rideid).first()):
				return jsonify({"value": "exist"}),200
		else:
			return jsonify({"value": "no"}),200
	
	if(id == 6):
		rideid = request["rideid"]
		print(rideid)
		if(Rides.query.filter_by(id=rideid).first()):
			print("hello")
			return jsonify({"value": "exist"}),200
		else:
			return jsonify({"value": "no"}),200
	
	if(id == 7):
		l = []
		for i in User.query.all():
			l.append(i.username)
		if(len(l) == 0):
			return jsonify([]), 204
		return jsonify(l), 200
	if(id == 8):
		num = len(Rides.query.all())
		return jsonify([num]), 200


def write_db(request):
	print("write_db api invoked in worker")
	print(request)
	id = request["id"]
	if(id == 1):
		uname = request["username"]
		pswd = request["password"]
		add_new_user = User(username=uname, password=pswd)
		db.session.add(add_new_user)
		#print(add_new_user)
		db.session.commit()
		#print(add_new_user)
	if(id == 2):
		uname = request["username"]
		rm_user = User.query.filter_by(username=uname).first()
		db.session.delete(rm_user)
		db.session.commit()
	if(id == 3):
		uname = request["created_by"]
		datetime = request["timestamp"]
		src = request["source"]
		dst = request["destination"]
		add_new_ride = Rides(created_by=uname, timestamp=datetime,
                       source=src, destination=dst)
		db.session.add(add_new_ride)
		db.session.commit()
	if(id == 4):
		uname = request["username"]
		rideid = request["rideid"]
		join_ride = ID_UNAME(rideid=rideid, username=uname)
		db.session.add(join_ride)
		db.session.commit()
	if(id == 5):
		rideid = request["rideid"]
		ride1 = ID_UNAME.query.filter_by(rideid=rideid).all()
		ride2 = Rides.query.filter_by(id=rideid).first()
		for i in ride1:
			db.session.delete(i)
		db.session.delete(ride2)
		db.session.commit()
	if(id == 6):
		for i in Rides.query.all():
			db.session.delete(i)
		for i in ID_UNAME.query.all():
			db.session.delete(i)
		for i in User.query.all():
			db.session.delete(i)
		db.session.commit()
	return {},200



import pika

connection = pika.BlockingConnection(
    pika.ConnectionParameters(host='172.17.0.1'))

channel = connection.channel()

sq = channel.queue_declare(queue='syncQ')
q = sq.method.queue
channel.exchange_declare(exchange='syncX', exchange_type='fanout')
channel.queue_bind(exchange='syncX', queue=q)

def on_read_request(ch, method, props, body):
	req = json.loads(body)
	resp = read_db(req)
	if resp != None:
		if type(resp) == tuple:
			try:
				data = resp[0].data
				data = data.decode()
			except:
				data = json.dumps(resp[0])
			payload = [data,resp[1]]
		else:
			# data = json.dumps(resp.json)
			payload = [resp.text, resp.status_code]
		print("payload:",payload)
	ch.basic_publish(exchange='',
                     routing_key=props.reply_to,
                     properties=pika.BasicProperties(
                         correlation_id=props.correlation_id),
                        # delivery_mode=2,  # make message persistent
                     body=json.dumps(payload))
	ch.basic_ack(delivery_tag=method.delivery_tag)


def on_sync_request(ch, method, props, body):
	req = json.loads(body)
	response = write_db(req)
	ch.basic_ack(delivery_tag=method.delivery_tag)


def on_write_request(ch, method, props, body):
	req = json.loads(body)
	response = write_db(req)
	ch.basic_ack(delivery_tag=method.delivery_tag)

	ch.basic_publish(exchange='syncX', routing_key='syncQ', body=body)

channel.basic_qos(prefetch_count=1)

def data_from_orch():
	r = requests.get(url='http://172.17.0.1/api/v1/slavedata')
	req = json.loads(r.text)
	for i in req: 			
		body = i["query"]
		write_db(body)

if __name__=="__main__":
	db.create_all()
	data_from_orch()
	if amIMaster=="YES":
		channel.queue_declare(queue='writeQ')
		channel.basic_consume(queue='writeQ', on_message_callback=on_write_request)
	else:
		channel.queue_declare(queue='readQ')
		channel.basic_consume(queue='readQ', on_message_callback=on_read_request)
		channel.basic_consume(queue='syncQ', on_message_callback=on_sync_request)
	with app.app_context():
		print(" [x] Awaiting RPC requests")
		channel.start_consuming()
