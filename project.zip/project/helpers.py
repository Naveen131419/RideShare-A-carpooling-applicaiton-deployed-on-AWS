from json import dumps

import requests

#RADDR = 'http://52.91.239.91/'
#UADDR = 'http://18.206.227.50/'
#ADDR = 'http://CC-380113097.us-east-1.elb.amazonaws.com/'

RADDR = 'http://0.0.0.0:8080'
UADDR = 'http://0.0.0.0:8081'

# API 1 Add User
def add_user(username, password):
	url = f"{UADDR}/api/v1/users"
	payload = {"username": username, "password": password}
	headers = {"Content-Type": "application/json"}
	r = requests.put(url, json=payload, headers=headers)
	return r.json(), r.status_code

# API 2 Remove User
def delete_user(username):
	url = f"{UADDR}/api/v1/users/{username}"
	r = requests.delete(url)
	# r = requests.post(url)
	return r.json(), r.status_code

# API 3 Create a new Ride
def create_ride(username, timestamp, source, destination):
	url = f"{RADDR}/api/v1/rides"
	payload = {"created_by": username, "timestamp": timestamp,
			   "source": source, "destination": destination}
	headers = {"Content-Type": "application/json"}
	r = requests.post(url, json=payload, headers=headers)
	if r.status_code == 204:
		return None,204
	# if r.status_code != 200:
	# 	return [r.text], r.status_code
	return r.json(), r.status_code

# API 4 List all upcoming Rides for a given source and destination
def list_rides(source, destination):
	url = f"{RADDR}/api/v1/rides?source={source}&destination={destination}"
	r = requests.get(url)
	if r.status_code == 204:
		return {},204
	return r.json(), r.status_code

# API 5 List all the details of a given ride
def ride_details(ride_id):
	url = f"{RADDR}/api/v1/rides/{ride_id}"
	r = requests.get(url)
	if r.status_code == 204:
		return None,204
	return r.json(), r.status_code

# API 6 Join an existing ride
def join_ride(ride_id, username):
	url = f"{RADDR}/api/v1/rides/{ride_id}"
	payload = {"username": username}
	headers = {"Content-Type": "application/json"}
	r = requests.post(url, json=payload, headers=headers)
	if r.status_code == 204:
		return None,204
	return r.json(), r.status_code

# API 7 Delete a ride
def delete_ride(ride_id):
	url = f"{RADDR}/api/v1/rides/{ride_id}"
	r = requests.delete(url)
	return r.json(), r.status_code

# API 10 List all users
def list_users():
	url = f"{UADDR}/api/v1/users"
	r = requests.get(url)
	if r.status_code == 204:
		return None,204
	return r.json(), r.status_code

def clear_user_db():
	url = f"{UADDR}/api/v1/db/clear"
	r = requests.post(url)
	return r.json(), r.status_code


def clear_ride_db():
	url = f"{RADDR}/api/v1/db/clear"
	r = requests.post(url)
	return r.json(), r.status_code

def total_requests_user():
	url = f"{UADDR}/api/v1/_count"
	r = requests.get(url)
	return r.text, r.status_code

def total_requests_ride():
	url = f"{RADDR}/api/v1/_count"
	r = requests.get(url)
	return r.text, r.status_code


def reset_requests_count_user():
	url = f"{UADDR}/api/v1/_count"
	r = requests.delete(url)
	return r.json(), r.status_code

def reset_requests_count_ride():
	url = f"{RADDR}/api/v1/_count"
	r = requests.delete(url)
	return r.json(), r.status_code

def count_rides():
	url = f"{RADDR}/api/v1/rides/count"
	r = requests.get(url)
	return r.text, r.status_code
