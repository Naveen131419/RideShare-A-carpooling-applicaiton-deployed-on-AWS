import requests, json
from flask import Flask, jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)

count=0


DBIP = "0.0.0.0:8082"

@app.route('/api/v1/rides',methods=['POST'])
def new_ride():
	global count
	count+=1
	if request.method == 'POST':
		uname=request.get_json()["created_by"]
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":1,"username":uname})
		r=json.loads(r.text)
		if(r["value"]=="exist"):
			#print("hello")
			datetime=request.get_json()["timestamp"]
			src=request.get_json()["source"]
			dst=request.get_json()["destination"]
			new_data={"id":3,"created_by":uname,"timestamp":datetime,"source":src,"destination":dst}
			r1=requests.post(url=f'http://{DBIP}/api/v1/db/write',json=new_data)
			if r1.status_code==200:
				return {},201
		else:
			return jsonify("user"),400
	return {},405

@app.route('/api/v1/rides',methods=['GET'])
def upcumming_rides():
	global count
	count+=1
	if request.method == 'GET':
		src=0
		dst=0
		src = request.args.get('source')
		dst = request.args.get('destination')
		if(src==0 or dst==0 or int(src)>199 or int(dst)>199):
			return {},400
		else:
			data={"id":3,"source":src,"destination":dst}
			r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json=data)
			list = r.json()["ridesList"]
			if(len(list)==0):
				return {},204
			return jsonify(list),200
	else:
		return {},405
		
@app.route('/api/v1/rides/<id>',methods=['GET'])
def ride_details(id):
	global count
	count+=1
	if request.method == 'GET':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":4,"rideid":id})
		if(r.status_code!=400):
			return jsonify(r.json()["data"])
		else:
			return {},400
	else:
		return {},405

@app.route('/api/v1/rides/<id>',methods=['POST'])
def join_ride(id):
	global count
	count+=1
	if request.method == 'POST':
		uname=request.get_json()["username"]
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read',json={"id":5,"username":uname,"rideid":id})
		r=json.loads(r.text)
		if(r["value"]=="exist"):
			new_data={"id":4,"rideid":id,"username":uname}
			r1=requests.post(url=f'http://{DBIP}/api/v1/db/write',json=new_data)
			if r1.status_code==200:
				return {},200
		else:
			return jsonify("user"),400
	else:
		return {},405

@app.route('/api/v1/rides/<id>',methods=['DELETE'])
def delete_ride(id):
	global count
	count+=1
	if request.method == 'DELETE':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":6,"rideid":id})	
		r=json.loads(r.text)
		if(r["value"]=="no"):
			return {},400
		else:
			r=requests.post(url=f'http://{DBIP}/api/v1/db/write', json={"id":5,"rideid":id})	
		return {}, 200
	else:
		return {},405

@app.route('/api/v1/db/clear',methods=['POST'])
def clear_db():
	if request.method == 'POST':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/write', json={"id":6})
		return {},200
	else:
		return {},405

@app.route('/api/v1/rides/count',methods=['GET'])
def count_ride():
	global count
	count+=1
	if request.method == 'GET':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":8})
		print("***",r)
		return jsonify(r.json()),200
	else:
		return {},405

@app.route('/api/v1/_count',methods=['GET','DELETE'])
def _count():
	global count
	if request.method == 'GET':
		return jsonify([count]),200
	elif request.method == 'DELETE':
		count=0
		return {},200
	else:
		return {},405

@app.route('/')
def hello_world():
	return 'Hello, World! From Rides'

if __name__=="__main__":
	app.run(debug=True,host="0.0.0.0",port=8080)
