import requests, json
from flask import Flask, jsonify
from flask import request
from flask_sqlalchemy import SQLAlchemy
import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///user.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS']=False

count=0

DBIP = "0.0.0.0:8082"

def check_passwd(passwd):
	if len(passwd) == 40:
		for i in passwd:
			if i not in "ABCDEF0123456789abcdef":
				return 0
		return 1
	return 0
	
#def check_date_time(timestamp):

	

@app.route('/api/v1/users',methods=['PUT'])
def add_user():
	global count
	count+=1
	if request.method == 'PUT':
		uname=request.get_json()["username"]
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":1,"username":uname})
		print("+++++++",r.text)
		r=json.loads(r.text)
		if(r["value"]=="no"):
			pswd=request.get_json()["password"]
			if(check_passwd(pswd)):
				#print("hello")
				new_data={"id":1,"username":uname,"password":pswd}
				r1=requests.post(url=f'http://{DBIP}/api/v1/db/write',json=new_data)
				if r1.status_code==200:
					return {},201
			else:
				return jsonify("invalid pwd"),400
		return jsonify("user"),400
	return jsonify(""),405


@app.route('/api/v1/users/<username>',methods=['DELETE'])
def delete_user(username):
	global count
	count+=1
	if request.method == 'DELETE':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":2,"username":username})
		r=json.loads(r.text)
		if(r["value"]=="no"):
			return {},400
		else:
			r=requests.post(url=f'http://{DBIP}/api/v1/db/write', json={"id":2,"username":username})
			return {}, 200
	else:
		return {},405

@app.route('/api/v1/db/clear',methods=['POST'])
def clear_db():
	if request.method == 'POST':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/write', json={"id":6})
		return {},200
	else:
		return {},405 

@app.route('/api/v1/users',methods=['GET'])
def list_users():
	global count
	count+=1
	if request.method == 'GET':
		r=requests.post(url=f'http://{DBIP}/api/v1/db/read', json={"id":7})
		print(r)
		if(r.status_code==204):
			return {},204
		else:
			return jsonify(r.json()),r.status_code
	else:
		return {},405

@app.route('/api/v1/_count',methods=['GET','DELETE'])
def _count():
	global count
	if request.method == 'GET':
		return jsonify([count]),200
	elif request.method == 'DELETE':
		count=0
		return {},200
	else:
		return {},405

@app.route('/')
def hello_world():
	return 'Hello, World! From Users'

if __name__=="__main__":
	app.run(debug=True,host="0.0.0.0",port=8081)
