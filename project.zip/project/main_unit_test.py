import json
from helpers import *
import subprocess

c_val_u = 0
c_val_r = 0

def test(op=None, ride_id=None, username=None, password=None, timestamp=None, source=None, destination=None, status_code=None, count_val=None):
	global c_val_r
	global c_val_u
	if (op == 1):
		js, sc = add_user(username, password)
	elif (op == 2):
		js, sc = delete_user(username)
	elif (op == 3):
		js, sc = create_ride(username, timestamp, source, destination)
	elif (op == 4):
		js, sc = list_rides(source, destination)
	elif (op == 5):
		js, sc = ride_details(ride_id)
	elif (op == 6):
		js, sc = join_ride(ride_id, username)
	elif (op == 7):
		js, sc = delete_ride(ride_id)
	elif (op == 10):
		js, sc = list_users()
	elif (op == "cud"):
		js, sc = clear_user_db()
	elif (op == "crd"):
		js, sc = clear_ride_db()
	elif (op == "rcu"):
		js, sc = total_requests_user()
		print(js, sc)
		assert json.loads(js)[0] - c_val_u == count_val
	elif (op == "rcr"):
		js, sc = total_requests_ride()
		print(js, sc)
		assert json.loads(js)[0] - c_val_r == count_val
	elif (op == "rrcu"):
		js, sc = reset_requests_count_user()
		c_val_u = 0
	elif (op == "rrcr"):
		js, sc = reset_requests_count_ride()
		c_val_r = 0
	elif (op == "rc"):
		js, sc = count_rides()
		print(js, sc)
		assert json.loads(js)[0] == count_val
	print(js, sc)
	assert sc == status_code
	print("***")


if __name__ == "__main__":
	#subprocess.call(["curl","-X","DELETE","http://0.0.0.0:818{1,2}/api/v1/_count"])
	# request count users test(op="rcu", count_val=0, status_code=200)
	# request count rides test(op="rcr", count_val=0, status_code=200)
	# clear user database
	test(op="cud", status_code=200)
	# clear ride database
	test(op="crd", status_code=200)
	# ride count in the beginning
	test(op="rc", count_val=0, status_code=200)
	# list all users, when no user in the database
	test(op=10,status_code=204)
	# Create a new user
	test(op=1, username='user', password='0123456789'*4, status_code=201)
	# Create another new user
	test(op=1, username='user_to_create_ride', password='0123456789'*4, status_code=201)
	# Create another new user
	test(op=1, username='user_to_join_ride', password='0123456789'*4, status_code=201)
	# Create a new user with existing username
	test(op=1, username='user', password='0123456789'*4, status_code=400)
	# Create a new user with wrong password
	test(op=1, username='new_user', password='0123456789', status_code=400)
	# delete a user
	test(op=2, username='user', status_code=200)
	# delete a non-existent user
	test(op=2, username='non-existent-user', status_code=400)
	# create a ride
	test(op=3, username='user_to_create_ride', timestamp='04-04-2021:40-22-07',
		 source='2', destination='5', status_code=201)
	# ride count
	test(op="rc", count_val=1, status_code=200)
	# create a ride with non-existent user
	test(op=3, username='non-existent-user', timestamp='04-04-2021:40-22-07',
		 source='2', destination='5', status_code=400)
	# create a ride with non-existent source or destination test(op=3, username='user_to_create_ride', timestamp='04-04-2021:40-22-07',source='220', destination='5', status_code=400)
	# create a ride with invlaid timestamp format test(op=3, username='user_to_create_ride', timestamp='04/04/2021:40-22-07', source='220', destination='5', status_code=400)
	# create a ride with invlaid date as timestamp test(op=3, username='user_to_create_ride', timestamp='44-04-2021:40-22-07', source='220', destination='5', status_code=400)
	# create a ride with the same source and destination test(op=3, username='user_to_create_ride', timestamp='04-04-2021:40-22-07', source='5', destination='5', status_code=400)
	# request count users test(op="rcu", count_val=12-1, status_code=200)
	# request count rides test(op="rcr", count_val=9-1, status_code=200)
	# reset request count users
	test(op="rrcr", status_code=200)
	# reset request count rides
	test(op="rrcu", status_code=200)
	# request count users test(op="rcu", count_val=0, status_code=200)
	# request count rides test(op="rcr", count_val=0, status_code=200)
	# list upcoming rides
	test(op=4, source='2', destination='5', status_code=200)
	# list upcoming rides with non-existent source or destination
	test(op=4, source='220', destination='5', status_code=400)
	# list upcoming rides with no ride from given source and destination test(op=4, source='20', destination='95', status_code=204)
	# list ride details
	test(op=5, ride_id=1, status_code=200)
	# list ride details of a non-existent ride
	test(op=5, ride_id=99, status_code=400)
	# join a ride
	test(op=6, ride_id=1, username='user_to_join_ride', status_code=200)
	# join a non-existent ride test(op=6, ride_id=99, username='user_to_join_ride', status_code=400)
	# join a ride by the user who created the ride test(op=6, ride_id=1, username='user_to_create_ride', status_code=400)
	# join a ride by a non-existent user
	test(op=6, ride_id=1, username='non-existent-user', status_code=400)
	# list ride details after someone joined a ride
	test(op=5, ride_id=1, status_code=200)
	# request count users test(op="rcu", count_val=4, status_code=200)
	# request count rides test(op="rcr", count_val=10, status_code=200)
	# delete a ride
	test(op=7, ride_id=1, status_code=200)
	# ride count after deleting a ride
	test(op="rc", count_val=0, status_code=200)
	# delete a non-existent ride test(op=7, ride_id=99, status_code=400)
	# list all users
	test(op=10,status_code=200)
	# request count users test(op="rcu", count_val=5, status_code=200)
	# request count rides test(op="rcr", count_val=13, status_code=200)
	# clear user database
	test(op="cud", status_code=200)
	# clear ride database
	test(op="crd", status_code=200)
	# request count users test(op="rcu", count_val=5, status_code=200)
	# request count rides test(op="rcr", count_val=13, status_code=200)

	


